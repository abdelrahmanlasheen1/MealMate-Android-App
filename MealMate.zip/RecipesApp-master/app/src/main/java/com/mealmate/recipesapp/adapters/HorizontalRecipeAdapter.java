package com.mealmate.recipesapp.adapters;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.meal.mateapp.R;
import com.meal.mateapp.databinding.ItemRecipeHorizontalBinding;
import com.mealmate.recipesapp.RecipeDetailsActivity;
import com.mealmate.recipesapp.models.Recipe;

import java.util.ArrayList;
import java.util.List;

public class HorizontalRecipeAdapter extends RecyclerView.Adapter<HorizontalRecipeAdapter.RecipeHolder> {

    // List to hold the recipe data that will be displayed
    List<Recipe> recipeList = new ArrayList<>();

    // Method to update the list of recipes and notify RecyclerView to update the UI
    public void setRecipeList(List<Recipe> recipeList) {
        this.recipeList.clear();  // Clear the current list to avoid duplication
        this.recipeList = recipeList;  // Set the new list of recipes
        notifyDataSetChanged();  // Notify the adapter that the data has changed
    }

    // Called when a new ViewHolder is needed. This creates a new RecipeHolder for each item in the list
    @NonNull
    @Override
    public HorizontalRecipeAdapter.RecipeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for the recipe item and return a new RecipeHolder instance
        return new RecipeHolder(ItemRecipeHorizontalBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    // Called to bind the data to a ViewHolder at a specific position
    @Override
    public void onBindViewHolder(@NonNull HorizontalRecipeAdapter.RecipeHolder holder, int position) {
        // Get the recipe for the current position in the list
        Recipe recipe = recipeList.get(position);
        // Bind the recipe data to the ViewHolder
        holder.onBind(recipe);
    }

    // Return the total number of items in the recipe list
    @Override
    public int getItemCount() {
        return recipeList.size();  // Return the size of the recipe list
    }

    // RecipeHolder is a ViewHolder that binds the recipe data to the views in the layout
    public static class RecipeHolder extends RecyclerView.ViewHolder {
        ItemRecipeHorizontalBinding binding;  // Reference to the binding for the horizontal item layout

        // Constructor to initialize the binding object
        public RecipeHolder(@NonNull ItemRecipeHorizontalBinding itemView) {
            super(itemView.getRoot());  // Get the root view of the layout
            binding = itemView;  // Set the binding object
        }

        // This method binds the data from the Recipe object to the views in the layout
        public void onBind(Recipe recipe) {
            // Load the recipe image using Glide
            Glide
                    .with(binding.getRoot().getContext())  // Use the context from the root view
                    .load(recipe.getImage())  // Load the recipe's image URL
                    .centerCrop()  // Crop the image to fit the ImageView
                    .placeholder(R.mipmap.ic_launcher)  // Set a placeholder image while the image loads
                    .into(binding.bgImgRecipe);  // Set the image to the ImageView

            // Set the recipe name in the TextView
            binding.tvRecipeName.setText(recipe.getName());

            // Set an OnClickListener for the whole item view
            binding.getRoot().setOnClickListener(view -> {
                // When the item is clicked, start the RecipeDetailsActivity to show more details about the recipe
                Intent intent = new Intent(binding.getRoot().getContext(), RecipeDetailsActivity.class);
                intent.putExtra("recipe", recipe);  // Pass the selected recipe object to the details activity
                binding.getRoot().getContext().startActivity(intent);  // Start the activity
            });
        }
    }
}
