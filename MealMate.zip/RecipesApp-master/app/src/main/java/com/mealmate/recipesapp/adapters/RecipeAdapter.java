package com.mealmate.recipesapp.adapters;

import static com.meal.mateapp.databinding.ItemRecipeBinding.inflate;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.meal.mateapp.R;
import com.meal.mateapp.databinding.ItemRecipeBinding;
import com.mealmate.recipesapp.RecipeDetailsActivity;
import com.mealmate.recipesapp.models.Recipe;

import java.util.ArrayList;
import java.util.List;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.RecipeHolder> {

    // List to hold the recipe data that will be displayed in the RecyclerView
    List<Recipe> recipeList = new ArrayList<>();

    // Method to update the list of recipes and notify RecyclerView to update the UI
    public void setRecipeList(List<Recipe> recipeList) {
        this.recipeList = recipeList;  // Set the new recipe list
        notifyDataSetChanged();  // Notify the adapter that the data has changed and the RecyclerView should be updated
    }

    // This method is called when a new ViewHolder is needed. It inflates the layout for each item
    @NonNull
    @Override
    public RecipeAdapter.RecipeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for the item and return a new RecipeHolder instance
        return new RecipeHolder(inflate(LayoutInflater.from(parent.getContext()), parent, false));
    }

    // This method binds the data to the views in the ViewHolder at a specific position
    @Override
    public void onBindViewHolder(@NonNull RecipeAdapter.RecipeHolder holder, int position) {
        Recipe recipe = recipeList.get(position);  // Get the recipe at the current position
        holder.onBind(recipe);  // Bind the recipe data to the ViewHolder
    }

    // Return the total number of items in the recipe list
    @Override
    public int getItemCount() {
        return recipeList.size();  // Return the size of the recipe list
    }

    // RecipeHolder is a ViewHolder that binds the recipe data to the views in the layout
    public static class RecipeHolder extends RecyclerView.ViewHolder {

        ItemRecipeBinding binding;  // Binding object to hold the views in the layout

        // Constructor to initialize the binding object with the inflated layout
        public RecipeHolder(@NonNull ItemRecipeBinding itemView) {
            super(itemView.getRoot());  // Get the root view of the layout
            binding = itemView;  // Set the binding object
        }

        // Method to bind the recipe data (image and name) to the views in the layout
        public void onBind(Recipe recipe) {
            // Use Glide to load the recipe image into the ImageView
            Glide
                    .with(binding.getRoot().getContext())  // Use the context from the root view
                    .load(recipe.getImage())  // Load the image from the recipe's URL
                    .centerCrop()  // Crop the image to fit the ImageView
                    .placeholder(R.drawable.recipe1)  // Set a placeholder image while the image is loading
                    .into(binding.bgImgRecipe);  // Set the image into the ImageView (bgImgRecipe)

            // Set the recipe name in the TextView
            binding.tvRecipeName.setText(recipe.getName());  // Display the recipe name in the TextView

            // Set a click listener for the entire item view
            binding.getRoot().setOnClickListener(view -> {
                // When the item is clicked, start the RecipeDetailsActivity to show more details
                Intent intent = new Intent(binding.getRoot().getContext(), RecipeDetailsActivity.class);
                intent.putExtra("recipe", recipe);  // Pass the selected recipe object to the details activity
                binding.getRoot().getContext().startActivity(intent);  // Start the activity
            });
        }
    }
}
