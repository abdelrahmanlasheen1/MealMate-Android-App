package com.mealmate.recipesapp;

import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Marker;
import com.meal.mateapp.R;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {
    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        // Initialize map fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Get location data from intent
        double latitude = getIntent().getDoubleExtra("lat", 0);
        double longitude = getIntent().getDoubleExtra("lng", 0);
        String storeName = getIntent().getStringExtra("storeName");
        String description = getIntent().getStringExtra("description");

        // Add marker to the map
        LatLng location = new LatLng(latitude, longitude);
        Marker marker = mMap.addMarker(new MarkerOptions()
                .position(location)
                .title(storeName)
                .snippet(description));

        // Move camera to the marker
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 15));

        // Set marker click listener
        mMap.setOnMarkerClickListener(clickedMarker -> {
            showStoreInfoDialog(clickedMarker.getTitle(), clickedMarker.getSnippet());
            return false; // Event not consumed
        });
    }

    private void showStoreInfoDialog(String storeName, String description) {
        // Show store information in a dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(storeName)
                .setMessage(description)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }
}
