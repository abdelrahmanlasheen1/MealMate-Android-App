package com.mealmate.recipesapp.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.meal.mateapp.R;
import com.mealmate.recipesapp.adapters.Adapter;
import com.mealmate.recipesapp.models.Meals;
import com.mealmate.recipesapp.service.APIClient;
import com.mealmate.recipesapp.service.APIService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchFragment extends Fragment {

    private APIService apiService;  // API service for making network requests
    private List<Meals.Items> mealsList = new ArrayList<>();  // List to store meals retrieved from API
    private RecyclerView recyclerView;  // RecyclerView for displaying the list of meals
    private Adapter adapter;  // Adapter for managing the display of meals in RecyclerView
    private SearchView searchView;  // SearchView for searching meals

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the fragment layout and initialize views
        View view = inflater.inflate(R.layout.fragment_category, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);  // Initialize RecyclerView from layout

        // Set up the adapter with the context and meals list, and attach it to RecyclerView
        adapter = new Adapter(requireContext(), mealsList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));  // Set layout manager to display items linearly

        apiService = APIClient.createService(APIService.class);  // Create API service instance

        fetchAllMeals(); // Fetch all meals initially from the API

        return view;
    }

    // Method to fetch all meals from the API
    private void fetchAllMeals() {
        Call<Meals> call = apiService.getMenu();  // API call to get the menu
        call.enqueue(new Callback<Meals>() {  // Handle API response asynchronously
            @Override
            public void onResponse(Call<Meals> call, Response<Meals> response) {
                // Check if response is successful and has data
                if (response.isSuccessful() && response.body() != null) {
                    mealsList.clear();  // Clear the list to avoid duplicate entries
                    mealsList.addAll(response.body().getItemsList());  // Add fetched items to the list
                    adapter.notifyDataSetChanged();  // Notify adapter to refresh RecyclerView display
                } else {
                    Log.d("FETCH", "No meals found.");  // Log message if no meals were retrieved
                }
            }

            @Override
            public void onFailure(Call<Meals> call, Throwable t) {
                Log.e("FETCH", "Failed to fetch meals: " + t.getMessage());  // Log error if request fails
            }
        });
    }
}
