package com.mealmate.recipesapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.meal.mateapp.R;
import com.meal.mateapp.databinding.ActivityRecipeDetailsBinding;
import com.mealmate.recipesapp.models.FavouriteRecipe;
import com.mealmate.recipesapp.models.Recipe;
import com.mealmate.recipesapp.room.RecipeRepository;

public class RecipeDetailsActivity extends AppCompatActivity {
    ActivityRecipeDetailsBinding binding;
    private static final int REQUEST_CODE_CONTACT = 100;
    private static final int REQUEST_CODE_SMS_PERMISSION = 101;
    private String smsMessage; // Variable to store the SMS message

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRecipeDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
    }

    private void init() {
        Recipe recipe = (Recipe) getIntent().getSerializableExtra("recipe");
        binding.tvName.setText(recipe.getName());
        binding.tcCategory.setText(recipe.getCategory());
        binding.tvDescription.setText(recipe.getDescription());
        binding.tvCalories.setText(String.format("%s Calories", recipe.getCalories()));
        Glide.with(RecipeDetailsActivity.this)
                .load(recipe.getImage())
                .centerCrop()
                .placeholder(R.mipmap.ic_launcher)
                .into(binding.imgRecipe);

        if (recipe.getAuthorId().equalsIgnoreCase(FirebaseAuth.getInstance().getUid())) {
            binding.imgEdit.setVisibility(View.VISIBLE);
            binding.btnDelete.setVisibility(View.VISIBLE);
        } else {
            binding.imgEdit.setVisibility(View.GONE);
            binding.btnDelete.setVisibility(View.GONE);
        }
        binding.imgMap.setOnClickListener(view -> {
            Intent intent = new Intent(RecipeDetailsActivity.this, MapActivity.class);
            // Pass latitude, longitude, store name, and description to the MapActivity
            intent.putExtra("lat", recipe.getLatitude());
            intent.putExtra("lng", recipe.getLongitude());
            intent.putExtra("storeName", recipe.getStoreName());
            intent.putExtra("description", recipe.getDescription());
            startActivity(intent);
        });

        binding.imgEdit.setOnClickListener(view -> {
            Intent intent = new Intent(binding.getRoot().getContext(), AddRecipeActivity.class);
            intent.putExtra("recipe", recipe);
            intent.putExtra("isEdit", true);
            binding.getRoot().getContext().startActivity(intent);
        });

        checkFavorite(recipe);
        binding.imgFvrt.setOnClickListener(view -> favouriteRecipe(recipe));
        binding.btnDelete.setOnClickListener(view -> deleteRecipe(recipe));

        // Set the click listener for img_grocer
        binding.imgGrocer.setOnClickListener(view -> showEditDialog(recipe.getDescription()));

        updateDataWithFireBase(recipe.getId());
    }

    private void showEditDialog(String description) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_text, null);
        EditText etMessage = dialogView.findViewById(R.id.et_message);
        View btnCancel = dialogView.findViewById(R.id.btn_cancel);
        View btnSend = dialogView.findViewById(R.id.btn_send);

        etMessage.setText(description);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSend.setOnClickListener(v -> {
            String message = etMessage.getText().toString().trim();
            if (!message.isEmpty()) {
                showSendOptions(message);
            } else {
                Toast.makeText(this, "Please enter a message", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void showSendOptions(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Send via")
                .setMessage("Choose how you want to send the message.")
                .setPositiveButton("WhatsApp", (dialog, which) -> sendViaWhatsApp(message))
                .setNegativeButton("SMS", (dialog, which) -> chooseContactForSMS(message))
                .setNeutralButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void sendViaWhatsApp(String message) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.setPackage("com.whatsapp");
        intent.putExtra(Intent.EXTRA_TEXT, message);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp is not installed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void chooseContactForSMS(String message) {
        this.smsMessage = message; // Store the message for later use

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_CONTACTS},
                    REQUEST_CODE_CONTACT);
        } else if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS},
                    REQUEST_CODE_SMS_PERMISSION);
        } else {
            Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
            startActivityForResult(intent, REQUEST_CODE_CONTACT);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_CONTACT && resultCode == RESULT_OK) {
            Uri contactUri = data.getData();
            String phoneNumber = getPhoneNumber(contactUri);

            if (phoneNumber != null) {
                sendViaSMS(phoneNumber, smsMessage);
            } else {
                Toast.makeText(this, "No phone number found", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @SuppressLint("Range")
    private String getPhoneNumber(Uri contactUri) {
        String phoneNumber = null;
        try (Cursor cursor = getContentResolver().query(contactUri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int id = cursor.getInt(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                String hasPhone = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));
                if (hasPhone.equals("1")) {
                    Cursor phones = getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{String.valueOf(id)},
                            null
                    );
                    if (phones != null && phones.moveToFirst()) {
                        phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        phones.close();
                    }
                }
            }
        }
        return phoneNumber;
    }

    private void sendViaSMS(String phoneNumber, String message) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("sms:" + phoneNumber));
        intent.putExtra("sms_body", message);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Unable to send SMS.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteRecipe(Recipe recipe) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Recipe")
                .setMessage("Are you sure you want to delete this recipe?")
                .setPositiveButton("Yes", (dialogInterface, i) -> {
                    ProgressDialog dialog = new ProgressDialog(this);
                    dialog.setMessage("Deleting...");
                    dialog.setCancelable(false);
                    dialog.show();
                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Recipes");
                    reference.child(recipe.getId()).removeValue().addOnCompleteListener(task -> {
                        dialog.dismiss();
                        if (task.isSuccessful()) {
                            Toast.makeText(this, "Recipe Deleted Successfully", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(this, "Failed to delete recipe", Toast.LENGTH_SHORT).show();
                        }
                    });
                })
                .setNegativeButton("No", (dialogInterface, i) -> dialogInterface.dismiss())
                .show();
    }

    private void checkFavorite(Recipe recipe) {
        RecipeRepository repository = new RecipeRepository(getApplication());
        boolean isFavourite = repository.isFavourite(recipe.getId());
        if (isFavourite) {
            binding.imgFvrt.setColorFilter(getResources().getColor(R.color.accent));
        } else {
            binding.imgFvrt.setColorFilter(getResources().getColor(R.color.black));
        }
    }

    private void favouriteRecipe(Recipe recipe) {
        RecipeRepository repository = new RecipeRepository(getApplication());
        boolean isFavourite = repository.isFavourite(recipe.getId());
        if (isFavourite) {
            repository.delete(new FavouriteRecipe(recipe.getId()));
            binding.imgFvrt.setColorFilter(getResources().getColor(R.color.black));
        } else {
            repository.insert(new FavouriteRecipe(recipe.getId()));
            binding.imgFvrt.setColorFilter(getResources().getColor(R.color.accent));
        }
    }

    private void updateDataWithFireBase(String id) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Recipes");
        reference.child(id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Recipe recipe = snapshot.getValue(Recipe.class);
                if (recipe != null) {
                    binding.tvName.setText(recipe.getName());
                    binding.tcCategory.setText(recipe.getCategory());
                    binding.tvDescription.setText(recipe.getDescription());
                    binding.tvCalories.setText(String.format("%s Calories", recipe.getCalories()));
                    Glide.with(RecipeDetailsActivity.this)
                            .load(recipe.getImage())
                            .centerCrop()
                            .placeholder(R.mipmap.ic_launcher)
                            .into(binding.imgRecipe);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("RecipeDetailsActivity", "Database error: " + error.getMessage());
            }
        });
    }
}
