package com.mealmate.recipesapp.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.meal.mateapp.databinding.FragmentFavouritesBinding;
import com.mealmate.recipesapp.adapters.RecipeAdapter;
import com.mealmate.recipesapp.models.FavouriteRecipe;
import com.mealmate.recipesapp.models.Recipe;
import com.mealmate.recipesapp.room.RecipeRepository;

import java.util.ArrayList;
import java.util.List;

public class FavouritesFragment extends Fragment {
    // Binding object to interact with the UI elements in the 'fragment_favourites.xml' layout.
    FragmentFavouritesBinding binding;

    // Repository instance to access favorite recipes stored in the local database.
    RecipeRepository recipeRepository;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the fragment's layout and bind it to the 'binding' object for easy access to views.
        binding = FragmentFavouritesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Load favorite recipes each time the fragment is visible to the user.
        loadFavorites();
    }

    // Method to load and display favorite recipes.
    private void loadFavorites() {
        // Initialize the repository for accessing favorite recipes in the local database.
        recipeRepository = new RecipeRepository(requireActivity().getApplication());

        // Retrieve all favorite recipes saved locally.
        List<FavouriteRecipe> favouriteRecipes = recipeRepository.getAllFavourites();

        // Check if the favorite list is empty.
        if (favouriteRecipes.isEmpty()) {
            // Show a toast message if there are no favorite recipes.
            Toast.makeText(requireContext(), "No Favourites", Toast.LENGTH_SHORT).show();

            // Hide the RecyclerView and show a message indicating there are no favorites.
            binding.rvFavourites.setVisibility(View.GONE);
            binding.noFavourites.setVisibility(View.VISIBLE);
        } else {
            // Set up the RecyclerView with a grid layout and 2 columns.
            binding.rvFavourites.setLayoutManager(new GridLayoutManager(requireContext(), 2));

            // Set an adapter for displaying recipes in the RecyclerView.
            binding.rvFavourites.setAdapter(new RecipeAdapter());

            // List to store Recipe objects fetched from Firebase.
            List<Recipe> recipes = new ArrayList<>();

            // Reference to the 'Recipes' node in Firebase Realtime Database.
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Recipes");

            // Add a listener to retrieve data from Firebase once.
            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    // Check if there are any child nodes under 'Recipes'.
                    if (snapshot.hasChildren()) {
                        // Iterate over each child node (each recipe in Firebase).
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            // Check each favorite recipe to see if it matches a recipe in Firebase.
                            for (FavouriteRecipe favouriteRecipe : favouriteRecipes) {
                                if (dataSnapshot.getKey().equals(favouriteRecipe.getRecipeId())) {
                                    // If a match is found, add the recipe to the local list.
                                    recipes.add(dataSnapshot.getValue(Recipe.class));
                                }
                            }
                        }

                        // Display the RecyclerView with the list of favorite recipes.
                        binding.rvFavourites.setVisibility(View.VISIBLE);
                        binding.noFavourites.setVisibility(View.GONE);

                        // Update the adapter with the list of favorite recipes.
                        RecipeAdapter adapter = (RecipeAdapter) binding.rvFavourites.getAdapter();
                        if (adapter != null) {
                            adapter.setRecipeList(recipes);
                        }

                    } else {
                        // If no recipes are found, show a message indicating no favorites.
                        binding.noFavourites.setVisibility(View.VISIBLE);
                        binding.rvFavourites.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // Log an error message if Firebase data retrieval is cancelled or fails.
                    Log.e("FavouritesFragment", "onCancelled: " + error.getMessage());
                }
            });
        }
    }
}
