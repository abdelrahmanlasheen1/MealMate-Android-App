package com.mealmate.recipesapp.service;

import com.mealmate.recipesapp.models.Meals;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface APIService {

    // API call to fetch a list of meals that start with the letter 'c'
    // The endpoint is "json/v1/1/search.php?f=c"
    @GET("json/v1/1/search.php?f=c")
    Call<Meals> getMenu();

    // API call to search for meals based on a query parameter
    // The @Query annotation adds the query parameter to the URL
    @GET("search.php")
    Call<Meals> searchMeal(@Query("s") String query);
}
