package com.mealmate.recipesapp.models;

import java.io.Serializable;

// Model class representing a recipe, implementing Serializable for easy data transfer
public class Recipe implements Serializable {
    private String id;             // Unique identifier for the recipe
    private String name;           // Name of the recipe
    private String image;          // URL or path to the recipe's image
    private String description;    // Description of the recipe
    private String category;       // Category of the recipe (e.g., breakfast, dessert)
    private String calories;       // Caloric information for the recipe
    private String time;           // Preparation time for the recipe
    private String authorId;       // ID of the author who created the recipe
    private String storeName;      // Name of the store associated with the recipe
    private double latitude;       // Latitude for the store location
    private double longitude;      // Longitude for the store location

    // Default constructor
    public Recipe() {}

    // Parameterized constructor to initialize all recipe attributes
    public Recipe(String name, String description, String time, String category, String calories, String image, String authorId, String storeName, double latitude, double longitude) {
        this.name = name;
        this.description = description;
        this.time = time;
        this.category = category;
        this.calories = calories;
        this.image = image;
        this.authorId = authorId;
        this.storeName = storeName;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // Getter and setter for recipe ID
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // Getter and setter for recipe name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and setter for image URL or path
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    // Getter and setter for recipe description
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Getter and setter for recipe category
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    // Getter and setter for calories information
    public String getCalories() {
        return calories;
    }

    public void setCalories(String calories) {
        this.calories = calories;
    }

    // Getter and setter for preparation time
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    // Getter and setter for author ID
    public String getAuthorId() {
        return authorId;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    // Getter and setter for store name
    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    // Getter and setter for latitude
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    // Getter and setter for longitude
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
