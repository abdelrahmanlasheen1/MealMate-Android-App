package com.mealmate.recipesapp.room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.mealmate.recipesapp.models.FavouriteRecipe;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {FavouriteRecipe.class}, version = 1, exportSchema = false)
// This annotation defines the Room Database, listing entities (tables) and the schema version.
public abstract class RecipeDatabase extends RoomDatabase {

    // Returns the current instance of the RecipeDatabase (Singleton pattern)
    public static RecipeDatabase getInstance() {
        return instance;
    }

    // Sets the RecipeDatabase instance
    public static void setInstance(RecipeDatabase instance) {
        RecipeDatabase.instance = instance;
    }

    // Abstract method for the DAO (Data Access Object), which provides methods to interact with the database.
    public abstract RecipeDao favouriteDao();

    // Singleton instance of the RecipeDatabase
    private static RecipeDatabase instance = null;

    // Number of threads for executing database operations asynchronously
    private static final int NUMBER_OF_THREADS = 4;

    // ExecutorService used to run database operations in a background thread pool
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    // Synchronized method to get the instance of RecipeDatabase
    // Ensures that only one instance of the database is created (singleton pattern)
    public static synchronized RecipeDatabase getInstance(Context context) {
        if (getInstance() == null) {
            setInstance(Room.databaseBuilder(context.getApplicationContext(), RecipeDatabase.class, "recipe_database")
                    .fallbackToDestructiveMigration() // If migration is not found, the database will be recreated
                    .build());
        }
        return getInstance();
    }
}
