package com.mealmate.recipesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.meal.mateapp.databinding.ActivitySplashBinding;

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {
    private final int splashScreenTime = 1000; // How long the splash screen should show (in ms)
    private final int timeInterval = 100; // How often the progress bar updates
    private int progress = 0; // Start progress from 0
    private Runnable runnable;
    private Handler handler;

    private ActivitySplashBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater()); // Set up the splash screen layout
        setContentView(binding.getRoot());
        binding.progressBar.setMax(splashScreenTime); // Set the progress bar to fill in the given time
        binding.progressBar.setProgress(progress); // Start the progress bar at 0
        handler = new Handler(Looper.getMainLooper()); // Create a handler to run tasks on the main thread
        runnable = () -> {
            if (progress < splashScreenTime) {
                progress += timeInterval; // Move the progress bar forward
                binding.progressBar.setProgress(progress); // Update the progress bar
                handler.postDelayed(runnable, timeInterval); // Keep updating until time's up
            } else {
                FirebaseApp.initializeApp(this); // Initialize Firebase just in case
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); // Check if the user is logged in
                // If the user is logged in, send them to the main screen; if not, send them to the login screen
                Intent nextActivity = (user != null) ? new Intent(SplashActivity.this, MainActivity.class) : new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(nextActivity); // Launch the next screen
                finish(); // Close the splash screen
            }
        };
        handler.postDelayed(runnable, timeInterval); // Start the progress bar updates
    }
}
