package com.mealmate.recipesapp.service;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class APIClient {

    // Base URL for the API endpoints
    public static final String BASE_URL = "https://www.themealdb.com/api/";

    // Generic method to create a service class for Retrofit
    public static <Api> Api createService(Class<Api> serviceClass) {
        // Creating a Retrofit builder
        Retrofit.Builder builder =
                new Retrofit.Builder()
                        // Set the base URL for the API
                        .baseUrl(BASE_URL)
                        // Add Gson converter for JSON serialization and deserialization
                        .addConverterFactory(GsonConverterFactory.create())
                        // Set the HTTP client (OkHttpClient)
                        .client(new OkHttpClient());

        // Build the Retrofit instance
        Retrofit retrofit = builder.build();

        // Create and return the API service class based on the passed class type
        return retrofit.create(serviceClass);
    }
}
