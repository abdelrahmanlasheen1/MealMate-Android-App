package com.mealmate.recipesapp.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Defines the FavouriteRecipe entity for the Room database with a table name "favourite_recipes"
@Entity(tableName = "favourite_recipes")
public class FavouriteRecipe {

    // Primary key for the table with auto-increment enabled
    @PrimaryKey(autoGenerate = true)
    private long id;

    // Stores the ID of the recipe that is marked as a favorite
    private String recipeId;

    // Constructor to initialize FavouriteRecipe with a recipe ID
    public FavouriteRecipe(String recipeId) {
        this.recipeId = recipeId;
    }

    // Getter for the ID of the favorite recipe entry
    public long getId() {
        return id;
    }

    // Getter for the recipe ID of the favorite recipe
    public String getRecipeId() {
        return recipeId;
    }

    // Setter for the ID of the favorite recipe entry
    public void setId(long id) {
        this.id = id;
    }

    // Setter for the recipe ID of the favorite recipe
    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }
}
