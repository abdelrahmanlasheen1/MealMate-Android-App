package com.mealmate.recipesapp.room;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.mealmate.recipesapp.models.FavouriteRecipe;

import java.util.List;

@Dao // This annotation indicates that this interface is a Data Access Object (DAO) for Room
public interface RecipeDao {

    // Inserts a new FavouriteRecipe into the database and returns its ID
    @Insert
    long insert(FavouriteRecipe recipe);

    // Deletes a FavouriteRecipe by its recipeId
    @Query("DELETE FROM favourite_recipes WHERE recipeId = :id")
    void delete(String id);

    // Retrieves all FavouriteRecipe records from the database
    @Query("SELECT * FROM favourite_recipes")
    List<FavouriteRecipe> getAll();

    // Retrieves a specific FavouriteRecipe based on the recipeId
    @Query("SELECT * FROM favourite_recipes WHERE recipeId = :favouriteName")
    FavouriteRecipe getFavourite(String favouriteName);

    // Retrieves a list of all FavouriteRecipe records from the database (same as getAll(), redundant here)
    @Query("SELECT * FROM favourite_recipes")
    List<FavouriteRecipe> getAllFavourites();
}
