package com.mealmate.recipesapp.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.meal.mateapp.R;
import com.mealmate.recipesapp.DetailActivity;
import com.mealmate.recipesapp.models.Meals;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<Meals.Items> items;  // List to hold the meal items
    private LayoutInflater inflater;   // LayoutInflater to inflate the custom layout for each item

    // Constructor to initialize the adapter with the context and list of meal items
    public Adapter(Context context, List<Meals.Items> items) {
        inflater = LayoutInflater.from(context);  // Get the inflater from the context
        this.items = items;  // Set the list of items
    }

    // This method is called to create a new ViewHolder object. It inflates the layout for each item.
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.menu_item, parent, false); // Inflate the item layout
        return new ViewHolder(view);  // Return a new ViewHolder instance with the inflated view
    }

    // This method binds data to the ViewHolder for a specific position in the list
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ViewHolder viewHolder = holder;  // Get the current ViewHolder

        // Set the name of the meal in the TextView
        viewHolder.name.setText(items.get(position).getStrMeal());

        // Set the description of the meal in the TextView
        viewHolder.desc.setText(items.get(position).getStrInstructions());

        // Use Glide to load the image into the ImageView from the URL
        Glide.with(holder.itemView).load(items.get(position).getStrMealThumb()).into(viewHolder.img);

        // Set a click listener on the "recipe" button to open the meal's YouTube link
        viewHolder.recipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);  // Create an intent to open a URL
                intent.setData(Uri.parse(items.get(position).getStrYoutube()));  // Set the URL to the meal's YouTube link
                v.getContext().startActivity(intent);  // Start the activity that opens the URL
            }
        });

        // Set a click listener on the "read more" button to open the DetailActivity with more information
        viewHolder.readmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailActivity.class);  // Create an intent to open the DetailActivity
                intent.putExtra("name", items.get(position).getStrMeal());  // Pass the meal name
                intent.putExtra("desc", items.get(position).getStrInstructions());  // Pass the meal description
                v.getContext().startActivity(intent);  // Start the DetailActivity
            }
        });
    }

    // This method returns the number of items in the list
    @Override
    public int getItemCount() {
        return items.size();  // Return the size of the list of meal items
    }

    // ViewHolder class to hold references to the views for each item
    class ViewHolder extends RecyclerView.ViewHolder {

        ImageView img;  // ImageView to display the meal's image
        TextView name, desc, readmore;  // TextViews to display the name, description, and the "read more" button text
        Button recipe;  // Button to open the YouTube recipe link

        // Constructor to initialize the views
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            img = itemView.findViewById(R.id.img);  // Find the ImageView by ID
            name = itemView.findViewById(R.id.name);  // Find the TextView for the name
            desc = itemView.findViewById(R.id.desc);  // Find the TextView for the description
            readmore = itemView.findViewById(R.id.readmore);  // Find the TextView for "read more"
            recipe = itemView.findViewById(R.id.recipe);  // Find the Button for the recipe link
        }
    }
}
