package com.mealmate.recipesapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.meal.mateapp.R;

public class DetailActivity extends AppCompatActivity {

    // Declare variables for the back button and text views
    ImageButton back;
    TextView name, desc;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_detail);  // Set the layout for this activity

        // Initialize the back button and set its click listener to navigate back to MainActivity
        back = findViewById(R.id.back);
        back.setOnClickListener(v -> {
            Intent intent = new Intent(getApplication(), MainActivity.class);
            startActivity(intent);  // Navigate back to MainActivity
        });

        // Initialize the TextViews to display recipe details
        name = findViewById(R.id.name);
        desc = findViewById(R.id.desc);

        // Get the passed data (name and description) from the intent
        String nameExtra = getIntent().getStringExtra("name");
        String descExtra = getIntent().getStringExtra("desc");

        // Set the received data to the respective TextViews
        name.setText(nameExtra);
        desc.setText(descExtra);
    }
}
