package com.mealmate.recipesapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.meal.mateapp.databinding.FragmentHomeBinding;
import com.mealmate.recipesapp.AllRecipesActivity;
import com.mealmate.recipesapp.adapters.HorizontalRecipeAdapter;
import com.mealmate.recipesapp.models.Recipe;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HomeFragment extends Fragment {

    // Binding object to easily access views in 'fragment_home.xml'
    private FragmentHomeBinding binding;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout and assign it to the binding object
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        // Load recipes when the fragment is resumed
        loadRecipes();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Set up a search action listener on the search bar
        binding.etSearch.setOnEditorActionListener((textView, i, keyEvent) -> {
            if (i == EditorInfo.IME_ACTION_SEARCH) {
                performSearch(); // Trigger search if the search action is performed
                return true;
            }
            return false;
        });

        // Set up a click listener for "See All Favourite" text to open AllRecipesActivity with a filter for favourites
        binding.tvSeeAllFavourite.setOnClickListener(view1 -> {
            Intent intent = new Intent(requireContext(), AllRecipesActivity.class);
            intent.putExtra("type", "favourite");
            startActivity(intent);
        });

        // Set up a click listener for "See All Popular" text to open AllRecipesActivity with a filter for popular recipes
        binding.tvSeeAllPopulars.setOnClickListener(view1 -> {
            Intent intent = new Intent(requireContext(), AllRecipesActivity.class);
            intent.putExtra("type", "popular");
            startActivity(intent);
        });
    }

    // Method to handle the search functionality
    private void performSearch() {
        // Retrieve and trim the text entered by the user in the search bar
        String query = Objects.requireNonNull(binding.etSearch.getText()).toString().trim();

        // Start AllRecipesActivity with a search query filter
        Intent intent = new Intent(requireContext(), AllRecipesActivity.class);
        intent.putExtra("type", "search");
        intent.putExtra("query", query);
        startActivity(intent);
    }

    // Method to load all recipes from the Firebase database
    private void loadRecipes() {
        // Set up initial adapters for popular and favourite recipes RecyclerViews
        binding.rvPopulars.setAdapter(new HorizontalRecipeAdapter());
        binding.rvFavouriteMeal.setAdapter(new HorizontalRecipeAdapter());

        // Firebase database reference pointing to the 'Recipes' node
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Recipes");

        // Fetch data from Firebase database
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Initialize a list to hold recipes
                List<Recipe> recipes = new ArrayList<>();

                // Loop through each recipe in the database
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Recipe recipe = dataSnapshot.getValue(Recipe.class);
                    recipes.add(recipe); // Add each recipe to the list
                }

                // Load recipes into the popular and favourite lists
                loadPopularRecipes(recipes);
                loadFavouriteRecipes(recipes);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Log any errors that occur while loading recipes
                Log.e("Error", error.getMessage());
            }
        });
    }

    // Method to load and display popular recipes in the RecyclerView
    private void loadPopularRecipes(List<Recipe> recipes) {
        if (recipes == null || recipes.isEmpty()) {
            // If there are no recipes, exit the method
            return;
        }

        // List to hold selected popular recipes
        List<Recipe> popularRecipes = new ArrayList<>();
        int numberOfRecipes = Math.min(5, recipes.size()); // Limit to 5 recipes or less if the list is smaller

        // Select random recipes from the list to display as popular
        for (int i = 0; i < numberOfRecipes; i++) {
            int random = (int) (Math.random() * recipes.size());
            popularRecipes.add(recipes.get(random));
        }

        // Update the adapter with the list of popular recipes
        HorizontalRecipeAdapter adapter = (HorizontalRecipeAdapter) binding.rvPopulars.getAdapter();
        if (adapter != null) {
            adapter.setRecipeList(popularRecipes);
        }
    }

    // Method to load and display favourite recipes in the RecyclerView
    private void loadFavouriteRecipes(List<Recipe> recipes) {
        if (recipes == null || recipes.isEmpty()) {
            // If there are no recipes, exit the method
            return;
        }

        // List to hold selected favourite recipes
        List<Recipe> favouriteRecipes = new ArrayList<>();
        int numberOfRecipes = Math.min(5, recipes.size()); // Limit to 5 recipes or less if the list is smaller

        // Select random recipes from the list to display as favourites
        for (int i = 0; i < numberOfRecipes; i++) {
            int random = (int) (Math.random() * recipes.size());
            favouriteRecipes.add(recipes.get(random));
        }

        // Update the adapter with the list of favourite recipes
        HorizontalRecipeAdapter adapter = (HorizontalRecipeAdapter) binding.rvFavouriteMeal.getAdapter();
        if (adapter != null) {
            adapter.setRecipeList(favouriteRecipes);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Nullify the binding when the view is destroyed to prevent memory leaks
        binding = null;
    }
}
