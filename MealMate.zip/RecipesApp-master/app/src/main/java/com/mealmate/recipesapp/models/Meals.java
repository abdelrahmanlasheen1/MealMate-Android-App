package com.mealmate.recipesapp.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

// Main class representing the Meals data structure received from the API
public class Meals {

    // List of meal items, deserialized from JSON "meals" array
    @SerializedName("meals")
    private List<Items> itemsList;

    // Getter for the list of meal items
    public List<Items> getItemsList() {
        return itemsList;
    }

    // Setter for the list of meal items
    public void setItemsList(List<Items> itemsList) {
        this.itemsList = itemsList;
    }

    // Inner class representing each individual meal item in the list
    public static class Items {

        // Meal name, mapped from JSON key "strMeal"
        @SerializedName("strMeal")
        private String strMeal;

        // URL of the meal thumbnail image, mapped from JSON key "strMealThumb"
        @SerializedName("strMealThumb")
        private String strMealThumb;

        // URL to the meal's YouTube video, mapped from JSON key "strYoutube"
        @SerializedName("strYoutube")
        private String strYoutube;

        // Cooking instructions for the meal, mapped from JSON key "strInstructions"
        @SerializedName("strInstructions")
        private String strInstructions;

        // Getter for the meal instructions
        public String getStrInstructions() {
            return strInstructions;
        }

        // Setter for the meal instructions
        public void setStrInstructions(String strInstructions) {
            this.strInstructions = strInstructions;
        }

        // Getter for the meal name
        public String getStrMeal() {
            return strMeal;
        }

        // Setter for the meal name
        public void setStrMeal(String strMeal) {
            this.strMeal = strMeal;
        }

        // Getter for the meal thumbnail URL
        public String getStrMealThumb() {
            return strMealThumb;
        }

        // Setter for the meal thumbnail URL
        public void setStrMealThumb(String strMealThumb) {
            this.strMealThumb = strMealThumb;
        }

        // Getter for the YouTube video URL
        public String getStrYoutube() {
            return strYoutube;
        }

        // Setter for the YouTube video URL
        public void setStrYoutube(String strYoutube) {
            this.strYoutube = strYoutube;
        }
    }
}
