package com.mealmate.recipesapp.models;

public class User {
    private String id;      // Unique identifier for the user
    private String name;    // Name of the user
    private String email;   // Email address of the user
    private String image;   // URL or path to the user's profile image
    private String cover;   // URL or path to the user's cover image

    // Default constructor
    public User() {
    }

    // Parameterized constructor to initialize all user attributes
    public User(String id, String name, String email, String image, String cover) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.image = image;
        this.cover = cover;
    }

    // Getter and setter for user ID
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // Getter and setter for user name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and setter for user email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter and setter for user image
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    // Getter and setter for user cover image
    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }
}
